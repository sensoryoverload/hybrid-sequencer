/*
 * soundtouch4c (A wrapper for soundtouch so you can use it in C programs)
 * Copyright (c) 2006-2009 J.A. Roberts Tunney and Anthony Minessale II
 *
 * Here we are implementing a basic wrapper around the SoundTouch
 * library.  Because SoundTouch likes to be tricky and switch between
 * float and short sample types, we're going to provide an interface
 * for shorts only, and translate to the SAMPLETYPE defined by
 * STTypes.h.  This way we shouldn't get that static garbage.
 *
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include "soundtouch4c.h"

extern "C" {

soundtouch4c_t SoundTouch_construct()
{
	return (soundtouch4c_t)(new SoundTouch());
}

void SoundTouch_destruct(soundtouch4c_t st)
{
	delete (SoundTouch *)st;
}

void SoundTouch_setRate(soundtouch4c_t st, float newRate)
{
	((SoundTouch *)st)->setRate(newRate);
}

void SoundTouch_setTempo(soundtouch4c_t st, float newTempo)
{
	((SoundTouch *)st)->setTempo(newTempo);
}

void SoundTouch_setRateChange(soundtouch4c_t st, float newRate)
{
	((SoundTouch *)st)->setRateChange(newRate);
}

void SoundTouch_setTempoChange(soundtouch4c_t st, float newTempo)
{
	((SoundTouch *)st)->setTempoChange(newTempo);
}

void SoundTouch_setPitch(soundtouch4c_t st, float newPitch)
{
	((SoundTouch *)st)->setPitch(newPitch);
}

void SoundTouch_setPitchOctaves(soundtouch4c_t st, float newPitch)
{
	((SoundTouch *)st)->setPitchOctaves(newPitch);
}

void SoundTouch_setPitchSemiTonesInt(soundtouch4c_t st, int newPitch)
{
	((SoundTouch *)st)->setPitchSemiTones(newPitch);
}

void SoundTouch_setPitchSemiTonesFloat(soundtouch4c_t st, float newPitch)
{
	((SoundTouch *)st)->setPitchSemiTones(newPitch);
}

void SoundTouch_setChannels(soundtouch4c_t st, uint numChannels)
{
	((SoundTouch *)st)->setChannels(numChannels);
}

void SoundTouch_setSampleRate(soundtouch4c_t st, uint srate)
{
	((SoundTouch *)st)->setSampleRate(srate);
}

void SoundTouch_flush(soundtouch4c_t st)
{
	((SoundTouch *)st)->flush();
}

void SoundTouch_putSamples(soundtouch4c_t st, float *samples, uint numSamples)
{
	((SoundTouch *)st)->putSamples(samples, numSamples);
}

void SoundTouch_clear(soundtouch4c_t st)
{
	((SoundTouch *)st)->clear();
}

int SoundTouch_setSetting(soundtouch4c_t st, uint settingId, uint value)
{
	return ((SoundTouch *)st)->setSetting(settingId, value);
}

uint SoundTouch_getSetting(soundtouch4c_t st, uint settingId)
{
	return ((SoundTouch *)st)->getSetting(settingId);
}

uint SoundTouch_numUnprocessedSamples(soundtouch4c_t st)
{
	return ((SoundTouch *)st)->numUnprocessedSamples();
}

uint SoundTouch_receiveSamples(soundtouch4c_t st, float *output, uint maxSamples)
{
	return ((SoundTouch *)st)->receiveSamples(output, maxSamples);
}

uint SoundTouch_numSamples(soundtouch4c_t st)
{
	return ((SoundTouch *)st)->numSamples();
}

int SoundTouch_isEmpty(soundtouch4c_t st)
{
	return ((SoundTouch *)st)->isEmpty();
}

}
 
/** EMACS **
 * Local variables:
 * mode: c++
 * tab-width: 4
 * indent-tabs-mode: t
 * c-basic-offset: 4
 * End:
 */
